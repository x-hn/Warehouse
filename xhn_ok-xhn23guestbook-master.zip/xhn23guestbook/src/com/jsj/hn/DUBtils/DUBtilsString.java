package com.jsj.hn.DUBtils;

public class DUBtilsString {
	public static boolean isNotNullandEmpety(String str) {
		if(str!=null && str!="") {
			return true;
		}else {
			return false;
		}
	}
}
